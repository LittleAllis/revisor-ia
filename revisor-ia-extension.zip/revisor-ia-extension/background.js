// Menú del clic derecho. No hace ninguna petición de red: solo pasa el texto seleccionado a la pestaña.
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'revisar', title: 'Revisar datos sensibles en la selección', contexts: ['selection'] });
  chrome.contextMenus.create({ id: 'restaurar', title: 'Restaurar datos enmascarados en la selección', contexts: ['selection'] });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const msg = { tipo: info.menuItemId, texto: info.selectionText || '' };
  try {
    // En las páginas de IA el script ya está; en las demás se inyecta ahora (permiso activeTab).
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['detector.js', 'content.js'] });
    await chrome.tabs.sendMessage(tab.id, msg);
  } catch (e) {
    console.warn('No se pudo revisar en esta pestaña (p. ej. páginas chrome:// o la tienda):', e.message);
  }
});
