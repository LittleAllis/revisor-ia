const DEF = { activo: true, politica: 'flexible', numerar: true };
const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(DEF, (v) => {
  $('activo').checked = v.activo;
  $('politica').value = v.politica;
  $('numerar').checked = v.numerar;
});
$('activo').onchange = (e) => chrome.storage.sync.set({ activo: e.target.checked });
$('politica').onchange = (e) => chrome.storage.sync.set({ politica: e.target.value });
$('numerar').onchange = (e) => chrome.storage.sync.set({ numerar: e.target.checked });
$('abrir').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('revisor.html') });
