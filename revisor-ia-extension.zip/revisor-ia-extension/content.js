/*
 * Revisa lo que el usuario pega o envía en las páginas de IA y ofrece enmascarar los datos sensibles.
 * Todo ocurre en esta pestaña: el texto nunca sale de aquí y la extensión no hace peticiones de red.
 */
(() => {
  if (window.__revisorIA) return; // el menú contextual puede inyectar este archivo otra vez
  window.__revisorIA = true;

  const D = self.Detector;
  const cfg = { activo: true, politica: 'flexible', numerar: true };
  try {
    chrome.storage.sync.get(cfg, (v) => Object.assign(cfg, v));
    chrome.storage.onChanged.addListener((c) => { for (const k in c) cfg[k] = c[k].newValue; });
  } catch (e) { /* sin chrome.storage (pruebas fuera de la extensión): usa los valores por defecto */ }

  // ---------- Enmascarado con etiquetas que no se repiten en toda la página ----------
  const mapa = {}, etiquetaDe = new Map(), cont = {};
  const ignorados = new Set(); // datos que el usuario decidió no enmascarar: no se vuelve a preguntar por ellos
  const clave = (h) => h.cat + '|' + h.texto;

  function enmascarar(texto, elegidos) {
    if (!cfg.numerar) return D.enmascarar(texto, elegidos);
    return [...elegidos].sort((a, b) => b.inicio - a.inicio).reduce((t, h) => {
      if (!etiquetaDe.has(clave(h))) {
        cont[h.cat] = (cont[h.cat] || 0) + 1;
        const e = `[${h.cat}_${cont[h.cat]}]`;
        etiquetaDe.set(clave(h), e); mapa[e] = h.texto;
      }
      return t.slice(0, h.inicio) + etiquetaDe.get(clave(h)) + t.slice(h.fin);
    }, texto);
  }

  function analizar(texto) {
    const hs = D.analizar(texto).hallazgos.filter((h) => !ignorados.has(clave(h)));
    return { hallazgos: hs, nivel: D.NIVELES[hs.reduce((x, h) => Math.max(x, h.riesgo), 0)] };
  }

  // ---------- Cuadro de texto de la IA ----------
  const esCampo = (el) => el instanceof HTMLTextAreaElement;
  const campoDe = (el) => (el instanceof Element ? el.closest('textarea, [contenteditable="true"], [contenteditable=""]') : null);
  let ultimoCampo = null;
  document.addEventListener('focusin', (e) => { const c = campoDe(e.target); if (c) ultimoCampo = c; }, true);
  const campoActual = () => (ultimoCampo && ultimoCampo.isConnected ? ultimoCampo
    : document.querySelector('#prompt-textarea, div.ProseMirror[contenteditable="true"], rich-textarea [contenteditable="true"], textarea'));
  const textoDe = (el) => (esCampo(el) ? el.value : el.innerText);

  function guardarSeleccion(el) {
    if (esCampo(el)) return { a: el.selectionStart, b: el.selectionEnd };
    const s = getSelection();
    return s.rangeCount && el.contains(s.anchorNode) ? s.getRangeAt(0).cloneRange() : null;
  }

  // Escribe en el cuadro como si el usuario pegara: así React/ProseMirror actualizan su estado.
  function insertar(el, texto, sel, todo) {
    el.focus();
    if (esCampo(el)) {
      if (todo) el.select(); else if (sel) el.setSelectionRange(sel.a, sel.b);
      if (!document.execCommand('insertText', false, texto)) {
        el.setRangeText(texto, el.selectionStart, el.selectionEnd, 'end');
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }
      return;
    }
    const s = getSelection();
    if (todo) { const r = document.createRange(); r.selectNodeContents(el); s.removeAllRanges(); s.addRange(r); }
    else if (sel) { s.removeAllRanges(); s.addRange(sel); }
    const dt = new DataTransfer();
    dt.setData('text/plain', texto);
    const ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
    el.dispatchEvent(ev); // evento no confiable: nuestro propio listener lo deja pasar
    if (!ev.defaultPrevented) document.execCommand('insertText', false, texto);
  }

  const esBotonEnviar = (b) => /\b(send|submit|enviar)\b|env[ií]a/i.test(
    [b.getAttribute('aria-label'), b.dataset.testid, b.title, b.textContent].join(' '));
  const buscarBotonEnviar = () => [...document.querySelectorAll('button')].find((b) => esBotonEnviar(b) && !b.disabled);

  // ---------- Interceptar pegar y enviar ----------
  let paseLibre = false, abierto = false;

  document.addEventListener('paste', (e) => {
    if (!cfg.activo || !e.isTrusted || abierto) return;
    const el = campoDe(e.target);
    const texto = e.clipboardData && e.clipboardData.getData('text/plain');
    if (!el || !texto) return;
    const r = analizar(texto);
    if (!r.hallazgos.length) return;
    e.preventDefault(); e.stopImmediatePropagation();
    const sel = guardarSeleccion(el);
    mostrar({ modo: 'pegado', texto, r,
      alEnmascarar: (t) => insertar(el, t, sel, false),
      alSinCambios: () => insertar(el, texto, sel, false),
      alCerrar: () => el.focus() });
  }, true);

  function revisarEnvio(e, el) {
    if (!cfg.activo || abierto) return;
    if (paseLibre) { paseLibre = false; return; }
    if (!el) return;
    const texto = textoDe(el);
    const r = analizar(texto);
    if (!r.hallazgos.length) return;
    e.preventDefault(); e.stopImmediatePropagation();
    mostrar({ modo: 'envio', texto, r,
      alEnmascarar: (t) => { insertar(el, t, null, true); aviso('Texto enmascarado. Revísalo y envía cuando quieras.'); },
      alSinCambios: () => {
        paseLibre = true;
        const b = buscarBotonEnviar();
        if (b) b.click(); else aviso('Vuelve a presionar Enviar: esta vez no se revisará.');
      },
      alCerrar: () => el.focus() });
  }

  window.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing || !e.isTrusted) return;
    const el = campoDe(e.target);
    if (el) revisarEnvio(e, el);
  }, true);

  window.addEventListener('click', (e) => {
    const b = e.target instanceof Element && e.target.closest('button');
    if (b && esBotonEnviar(b)) revisarEnvio(e, campoActual());
  }, true);

  // ---------- Menú del clic derecho ----------
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      const texto = String(getSelection()).trim() || msg.texto; // getSelection conserva los saltos de línea
      if (msg.tipo === 'revisar') {
        mostrar({ modo: 'seleccion', texto, r: analizar(texto),
          alEnmascarar: (t) => copiar(t, 'Versión enmascarada copiada.') });
      } else if (msg.tipo === 'restaurar') {
        mostrar({ modo: 'restaurar', texto: D.restaurar(texto, mapa) });
      }
    });
  } catch (e) { /* fuera de la extensión */ }

  async function copiar(t, ok) {
    try { await navigator.clipboard.writeText(t); aviso(ok); }
    catch (e) { aviso('No se pudo copiar automáticamente. Selecciona el texto y usa Ctrl+C.'); }
  }

  // ---------- Ventana de aviso (Shadow DOM: los estilos del sitio no la afectan) ----------
  const host = document.createElement('div');
  host.style.all = 'initial';
  const raiz = host.attachShadow({ mode: 'open' });
  raiz.innerHTML = `<style>
    :host { all: initial; }
    * { box-sizing: border-box; font: 15px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .fondo { position: fixed; inset: 0; z-index: 2147483647; background: rgba(0,0,0,.45); display: flex; align-items: center; justify-content: center; padding: 16px; }
    .caja { --bg:#fff; --tx:#1c2430; --mut:#5f6b7a; --bd:#d9dee5; --ac:#1d4ed8; --sub:#f6f7f9;
      background: var(--bg); color: var(--tx); width: min(640px, 100%); max-height: 90vh; overflow: auto; border-radius: 12px; padding: 18px; box-shadow: 0 10px 40px rgba(0,0,0,.3); }
    @media (prefers-color-scheme: dark) { .caja { --bg:#1b2129; --tx:#e6eaf0; --mut:#9aa6b5; --bd:#303a47; --ac:#3b82f6; --sub:#12161c; } }
    h2 { font-size: 17px; font-weight: 700; margin: 0 0 10px; }
    .banner { padding: 8px 12px; border-radius: 8px; font-weight: 600; margin-bottom: 10px; }
    .n-Ninguno { background:#dcfce7; color:#14532d } .n-Bajo { background:#e0e7ff; color:#312e81 }
    .n-Medio { background:#fef3c7; color:#78350f } .n-Alto { background:#fee2e2; color:#7f1d1d }
    .vista, textarea { white-space: pre-wrap; word-break: break-word; max-height: 160px; overflow: auto; padding: 8px; border: 1px solid var(--bd); border-radius: 8px; background: var(--sub); color: var(--tx); width: 100%; }
    textarea { min-height: 120px; resize: vertical; }
    mark { background: #fde68a; color: #1c2430; border-radius: 4px; padding: 0 2px; }
    ul { list-style: none; padding: 0; margin: 10px 0; }
    li { padding: 6px 0; border-bottom: 1px solid var(--bd); }
    label { cursor: pointer; display: flex; gap: 8px; align-items: flex-start; }
    code { font-family: ui-monospace, monospace; font-size: 13px; word-break: break-all; }
    .tag { font-size: 12px; font-weight: 700; padding: 0 6px; border-radius: 8px; background: var(--sub); border: 1px solid var(--bd); }
    .nota { color: var(--mut); font-size: 13px; }
    .fila { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; margin-top: 12px; }
    button { padding: 8px 14px; border-radius: 8px; border: 1px solid var(--bd); background: var(--bg); color: var(--tx); cursor: pointer; }
    button.p { background: var(--ac); border-color: var(--ac); color: #fff; }
    button:disabled { opacity: .5; cursor: not-allowed; }
    button:focus-visible, input:focus-visible { outline: 2px solid var(--ac); outline-offset: 2px; }
    .toast { position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 2147483647; background: #1c2430; color: #fff; padding: 10px 16px; border-radius: 8px; box-shadow: 0 4px 16px rgba(0,0,0,.3); }
  </style><div id="cont"></div>`;
  const $c = raiz.getElementById('cont');
  const esc = (s) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const montar = () => { if (!host.isConnected) document.documentElement.appendChild(host); };

  let tAviso;
  function aviso(txt) {
    montar();
    raiz.querySelector('.toast')?.remove();
    const t = Object.assign(document.createElement('div'), { className: 'toast', textContent: txt });
    t.setAttribute('role', 'status');
    raiz.appendChild(t);
    clearTimeout(tAviso); tAviso = setTimeout(() => t.remove(), 4000);
  }

  const TITULO = { pegado: 'Lo que vas a pegar tiene datos sensibles', envio: 'El mensaje tiene datos sensibles',
    seleccion: 'Revisión del texto seleccionado', restaurar: 'Texto con los datos restaurados' };
  const BOTON = { pegado: 'Pegar enmascarado', envio: 'Enmascarar en el cuadro', seleccion: 'Copiar enmascarado' };
  const SIN_CAMBIOS = { pegado: 'Pegar sin cambios', envio: 'Enviar sin cambios' };

  function mostrar({ modo, texto, r, alEnmascarar, alSinCambios, alCerrar }) {
    montar(); abierto = true;
    const estricta = cfg.politica === 'estricto';
    let html = `<div class="fondo"><div class="caja" role="dialog" aria-modal="true" aria-labelledby="t"><h2 id="t">${TITULO[modo]}</h2>`;

    if (modo === 'restaurar') {
      html += Object.keys(mapa).length ? '' : '<p class="nota">En esta pestaña no hay datos enmascarados para restaurar (la equivalencia se pierde al recargar la página).</p>';
      html += `<textarea readonly>${esc(texto)}</textarea><div class="fila"><button data-a="cerrar">Cerrar</button><button class="p" data-a="copiar">Copiar</button></div>`;
    } else {
      const hs = r.hallazgos;
      let vista = '', pos = 0;
      hs.forEach((h) => { vista += esc(texto.slice(pos, h.inicio)) + `<mark>${esc(h.texto)}</mark>`; pos = h.fin; });
      vista += esc(texto.slice(pos));
      html += hs.length
        ? `<div class="banner n-${r.nivel}">Nivel ${r.nivel.toUpperCase()} · ${hs.length} posible(s) dato(s) sensible(s)</div>
           <div class="vista">${vista}</div>
           <ul>${hs.map((h, i) => `<li><label><input type="checkbox" data-i="${i}" checked>
             <span><span class="tag">${h.cat}</span> <code>${esc(h.texto)}</code><br><span class="nota">${esc(D.MOTIVO[h.cat])}</span></span></label></li>`).join('')}</ul>
           <p class="nota" id="msg"></p>`
        : '<div class="banner n-Ninguno">No se encontraron datos sensibles con las reglas actuales.</div><p class="nota">La herramienta no detecta nombres propios ni direcciones. Revisa el texto tú mismo.</p>';
      html += '<div class="fila"><button data-a="cerrar">' + (modo === 'seleccion' ? 'Cerrar' : 'Cancelar') + '</button>';
      if (SIN_CAMBIOS[modo] && !(estricta && r.nivel === 'Alto')) html += `<button data-a="sin">${SIN_CAMBIOS[modo]}</button>`;
      if (hs.length) html += `<button class="p" data-a="mask">${BOTON[modo]}</button>`;
      html += '</div>';
    }
    $c.innerHTML = html + '</div></div>';

    const cajas = [...$c.querySelectorAll('input[type=checkbox]')];
    const elegidos = () => cajas.filter((c) => c.checked).map((c) => r.hallazgos[+c.dataset.i]);
    const btnMask = $c.querySelector('[data-a=mask]');
    const revisarPolitica = () => {
      if (!estricta || !btnMask) return;
      const queda = cajas.some((c) => !c.checked && r.hallazgos[+c.dataset.i].riesgo === 3);
      btnMask.disabled = queda;
      $c.querySelector('#msg').textContent = queda ? '⛔ Política estricta: todos los datos de riesgo alto deben enmascararse.' : '';
    };
    cajas.forEach((c) => (c.onchange = revisarPolitica));
    revisarPolitica();

    const cerrar = (fn) => {
      abierto = false; $c.innerHTML = ''; document.removeEventListener('keydown', teclas, true);
      (fn || alCerrar || (() => {}))();
    };
    const acciones = {
      cerrar: () => cerrar(),
      copiar: () => cerrar(() => copiar(texto, 'Texto restaurado copiado.')),
      sin: () => cerrar(alSinCambios),
      mask: () => {
        const sel = elegidos();
        r.hallazgos.filter((h) => !sel.includes(h)).forEach((h) => ignorados.add(clave(h)));
        const t = enmascarar(texto, sel);
        cerrar(() => alEnmascarar(t));
      },
    };
    $c.querySelectorAll('button').forEach((b) => (b.onclick = acciones[b.dataset.a]));
    function teclas(e) { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); cerrar(); } }
    document.addEventListener('keydown', teclas, true);
    (btnMask || $c.querySelector('button.p') || $c.querySelector('button')).focus();
  }

  window.__revisorIAPruebas = { mapa, cfg }; // solo para las pruebas automáticas
})();
