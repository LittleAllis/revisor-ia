const $ = (id) => document.getElementById(id);
const esc = (s) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pct = (x) => (x === null ? 'n/d' : (x * 100).toFixed(1) + ' %');
let actual = null, textoActual = '', ultimaEval = null, mapaActual = {};
const sesion = { analisis: 0, detectados: {}, enmascarados: {} };

function analizar() {
  textoActual = $('entrada').value;
  if (!textoActual.trim()) { $('resultado').hidden = true; $('final').hidden = true; return; }
  actual = Detector.analizar(textoActual);
  sesion.analisis++;
  actual.hallazgos.forEach((h) => { sesion.detectados[h.cat] = (sesion.detectados[h.cat] || 0) + 1; });
  pintarStats();
  const hs = actual.hallazgos;

  const ban = $('banner');
  ban.className = 'banner n-' + actual.nivel;
  ban.textContent = hs.length
    ? `Nivel de advertencia: ${actual.nivel.toUpperCase()} · ${hs.length} posible(s) dato(s) sensible(s) encontrado(s)`
    : 'No se encontraron datos sensibles con las reglas actuales. Ojo: la herramienta NO detecta nombres propios, direcciones ni números sin contexto. Revise el texto usted mismo.';

  let html = '', pos = 0;
  hs.forEach((h) => {
    html += esc(textoActual.slice(pos, h.inicio)) + `<mark style="background:var(--c-${h.cat})" title="${h.cat}">${esc(h.texto)}</mark>`;
    pos = h.fin;
  });
  $('vista').innerHTML = html + esc(textoActual.slice(pos));

  $('detalle').innerHTML = hs.length
    ? '<table><tr><th>Enmascarar</th><th>Categoría</th><th>Fragmento</th><th>Se reemplaza por</th><th>Por qué se marcó</th></tr>' +
      hs.map((h, i) => `<tr><td><input type="checkbox" class="sel" data-i="${i}" checked></td>
        <td><span class="tag" style="background:var(--c-${h.cat})">${h.cat}</span></td><td><code>${esc(h.texto)}</code></td><td>${h.etiqueta}</td><td class="nota">${Detector.MOTIVO[h.cat]}</td></tr>`).join('') + '</table>'
    : '';
  $('btnMask').hidden = !hs.length;
  $('resultado').hidden = false;
  if (!hs.length) { $('salida').value = textoActual; mostrarFinal(); } else { $('final').hidden = true; }
}

function mostrarFinal() { $('chkRevision').checked = false; $('msgCopia').textContent = ''; $('final').hidden = false; actualizarCopia(); }

function aplicar() {
  const elegidos = [...document.querySelectorAll('.sel')].filter((c) => c.checked).map((c) => actual.hallazgos[+c.dataset.i]);
  const r = Detector.enmascararReversible(textoActual, elegidos, $('chkNum').checked);
  $('salida').value = r.texto;
  mapaActual = r.mapa;
  elegidos.forEach((h) => { sesion.enmascarados[h.cat] = (sesion.enmascarados[h.cat] || 0) + 1; });
  pintarStats();
  $('restaurar').hidden = !Object.keys(mapaActual).length;
  $('respIA').value = ''; $('respRest').value = '';
  mostrarFinal();
}

// Política estricta: no permite copiar si en el texto final aún queda un dato de riesgo alto
function actualizarCopia() {
  const estricto = $('selPolitica').value === 'estricto';
  const bloqueado = estricto && Detector.analizar($('salida').value).nivel === 'Alto';
  $('btnCopiar').disabled = !$('chkRevision').checked || bloqueado;
  if (bloqueado) $('msgCopia').textContent = '⛔ Política estricta: aún hay datos de riesgo alto sin enmascarar. Vuelva al paso 2.';
  else if ($('msgCopia').textContent.startsWith('⛔')) $('msgCopia').textContent = '';
}

function pintarStats() {
  const cats = Detector.CATEGORIAS.filter((c) => sesion.detectados[c]);
  $('stats').textContent = sesion.analisis
    ? `Análisis realizados: ${sesion.analisis}. ` + (cats.length ? 'Detectados / enmascarados por categoría → ' + cats.map((c) => `${c}: ${sesion.detectados[c]}/${sesion.enmascarados[c] || 0}`).join(' · ') : 'Sin datos sensibles detectados.')
    : 'Aún no hay análisis. Solo se guardan conteos en memoria, nunca el texto.';
}

function descargarInforme() {
  const filas = Detector.CATEGORIAS.map((c) => [c, sesion.detectados[c] || 0, sesion.enmascarados[c] || 0].join(','));
  const csv = ['\ufeffinforme_de_sesion', 'fecha,' + new Date().toISOString(), 'politica,' + $('selPolitica').value,
    'analisis_realizados,' + sesion.analisis, 'nota,solo conteos; no contiene el texto analizado', '', 'categoria,detectados,enmascarados', ...filas].join('\n');
  const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })), download: 'informe_sesion.csv' });
  a.click(); URL.revokeObjectURL(a.href);
}

async function copiar() {
  const t = $('salida').value;
  try { await navigator.clipboard.writeText(t); }
  catch (e) { $('salida').select(); document.execCommand('copy'); }
  $('msgCopia').textContent = '✔ Copiado. Péguelo en la plataforma de IA que elija.';
}

function evaluar() {
  const r = ultimaEval = Detector.evaluar(BANCO);
  const filas = Detector.CATEGORIAS.map((c) => {
    const k = r.porCat[c], ex = k.vp + k.fn;
    return `<tr><td>${c}</td><td>${k.vp}</td><td>${k.fp}</td><td>${k.fn}</td><td>${ex ? pct(k.vp / ex) : 'n/d'}</td></tr>`;
  }).join('');
  const tipos = Object.entries(r.porTipo).map(([t, k]) => `<tr><td>${t}</td><td>${k.textos}</td><td>${k.vp}</td><td>${k.fp}</td><td>${k.fn}</td><td>${k.vp + k.fn ? pct(k.vp / (k.vp + k.fn)) : 'n/d'}</td></tr>`).join('');
  const fallos = r.detalle.filter((d) => d.fp || d.fn);
  $('metricas').innerHTML = `
    <div class="kpis">
      <div class="kpi"><b>${r.textos}</b>textos evaluados</div>
      <div class="kpi"><b>${pct(r.exhaustividad)}</b>tasa de detección (VP/(VP+FN))</div>
      <div class="kpi"><b>${pct(r.precision)}</b>precisión (VP/(VP+FP))</div>
      <div class="kpi"><b>${pct(r.tasaFP)}</b>falsos positivos en textos sin datos (FP/(FP+VN))</div>
      <div class="kpi"><b>${r.tiempoMs.toFixed(3)} ms</b>tiempo medio por texto</div>
    </div>
    <p class="nota">VP=${r.vp} · FP=${r.fp} · FN=${r.fn} (a nivel de dato) · Textos sin datos: ${r.vnTextos} sin alerta, ${r.fpTextos} con alerta falsa.
    Meta orientativa de detección ≥ 85 %: <b style="color:${r.cumpleMeta ? 'var(--ok)' : '#b91c1c'}">${r.cumpleMeta ? 'cumplida' : 'no cumplida'}</b> en este banco.</p>
    <div class="scroll"><table><tr><th>Categoría</th><th>VP</th><th>FP</th><th>FN</th><th>Detección</th></tr>${filas}</table></div>
    <h2 style="margin-top:14px">Resultados por tipo de caso</h2>
    <div class="scroll"><table><tr><th>Tipo</th><th>Textos</th><th>VP</th><th>FP</th><th>FN</th><th>Detección</th></tr>${tipos}</table></div>
    <h2 style="margin-top:14px">Casos con error (${fallos.length})</h2>
    <div class="scroll"><table><tr><th>#</th><th>Tipo</th><th>Esperado</th><th>Detectado</th><th>FP</th><th>FN</th></tr>
    ${fallos.map((d) => `<tr><td>${d.id}</td><td>${d.tipo}</td><td>${esc(d.esperado || '—')}</td><td>${esc(d.detectado || '—')}</td><td>${d.fp}</td><td>${d.fn}</td></tr>`).join('') || '<tr><td colspan="6">Sin errores.</td></tr>'}
    </table></div>`;
  $('btnCSV').disabled = false;
}

function descargarCSV() {
  const q = (s) => '"' + String(s).replace(/"/g, '""') + '"';
  const cab = ['id', 'tipo', 'texto', 'esperado', 'detectado', 'vp', 'fp', 'fn'];
  const filas = ultimaEval.detalle.map((d) => cab.map((c) => q(d[c])).join(','));
  const blob = new Blob(['\ufeff' + [cab.join(','), ...filas].join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: 'registro_pruebas.csv' });
  a.click(); URL.revokeObjectURL(a.href);
}

$('btnAnalizar').onclick = analizar;
$('btnLimpiar').onclick = () => { $('entrada').value = ''; $('resultado').hidden = true; $('final').hidden = true; mapaActual = {}; $('restaurar').hidden = true; };
$('btnEjemplo').onclick = () => { $('entrada').value = 'Resume esta solicitud del cliente Ana, correo ana.ejemplo@empresa.test y celular 300 123 4567'; analizar(); };
$('btnMask').onclick = aplicar;
$('chkRevision').onchange = actualizarCopia;
$('selPolitica').onchange = actualizarCopia;
$('btnRestaurar').onclick = () => { $('respRest').value = Detector.restaurar($('respIA').value, mapaActual); };
$('btnInforme').onclick = descargarInforme;
$('btnCopiar').onclick = copiar;
$('btnEval').onclick = evaluar;
$('btnCSV').onclick = descargarCSV;
