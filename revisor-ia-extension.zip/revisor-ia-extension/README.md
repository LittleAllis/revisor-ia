# Revisor de datos sensibles para IA (extensión de navegador)

Proyecto del Diplomado en Ciberseguridad · Corporación Universitaria Latinoamericana
Integrantes: Joel Martínez, Maicol Villalobos, Luis Aguilar

Extensión para Chrome y Edge (Manifest V3) que revisa el texto **antes** de que llegue a una IA
generativa. Funciona en ChatGPT, Gemini, Copilot y Claude. Todo corre en el navegador: la extensión
no tiene permiso para conectarse a internet y no envía el texto a ningún servidor.

## Instalación (modo desarrollador)
1. Descomprima la carpeta.
2. Abra `chrome://extensions` (en Edge: `edge://extensions`) y active **Modo de desarrollador**.
3. Pulse **Cargar descomprimida** y elija esta carpeta.
4. Fije el ícono del candado en la barra para tener a mano la configuración.

## Qué hace
| Momento | Comportamiento |
|---|---|
| **Pegar** en el cuadro de la IA | Si lo pegado tiene datos sensibles, aparece un aviso: *Pegar enmascarado*, *Pegar sin cambios* o *Cancelar*. |
| **Enviar** (Enter o botón Enviar) | Si el mensaje tiene datos sensibles, se detiene el envío: *Enmascarar en el cuadro*, *Enviar sin cambios* o *Cancelar*. |
| **Clic derecho → Revisar datos sensibles en la selección** | En cualquier página: muestra los hallazgos y copia la versión enmascarada. |
| **Clic derecho → Restaurar datos enmascarados en la selección** | Seleccione la respuesta de la IA: cambia `[CORREO_1]`, `[CELULAR_1]`… por los datos originales. |
| **Ícono de la extensión** | Activar o desactivar, política, etiquetas numeradas y acceso al revisor completo con el banco de pruebas. |

- En cada aviso se pueden desmarcar los datos que no se quieren ocultar. Esos datos no se vuelven a preguntar en esa pestaña.
- **Política estricta:** no aparece *Enviar/Pegar sin cambios* si hay un dato de riesgo alto, y no deja enmascarar dejando por fuera uno de esos datos.
- La equivalencia etiqueta → dato vive solo en la memoria de la pestaña. Se pierde al recargar o cerrar.

## Archivos
| Archivo | Contenido |
|---|---|
| `manifest.json` | Configuración de la extensión y permisos |
| `detector.js` | Motor de detección (el mismo del prototipo web) |
| `content.js` | Revisión al pegar o enviar en las páginas de IA y ventana de aviso |
| `background.js` | Opciones del clic derecho |
| `popup.html` / `popup.js` | Configuración |
| `revisor.html` / `revisor.js` | Revisor completo y banco de pruebas (la página original) |
| `banco_pruebas.js` / `evaluar.js` | Banco de 85 textos y evaluación en consola (`node evaluar.js`) |

## Permisos y por qué
- `storage`: guardar la configuración (nunca el texto).
- `contextMenus`, `activeTab`, `scripting`: el clic derecho revisa la selección en la pestaña actual solo cuando el usuario lo pide.
- Acceso solo a chatgpt.com, chat.openai.com, gemini.google.com, copilot.microsoft.com y claude.ai.

Evidencia de que todo es local: F12 → pestaña **Red/Network** en una página de IA. Al pegar o enviar,
la extensión no genera ninguna petición.

## Limitaciones conocidas
- Las reglas de detección son las del prototipo. Siguen pendientes los casos de evasión del informe
  («ana @ empresa.test», «(300) 123-4567», `DB_PASS=…`, etc.) y no se detectan nombres propios.
- Los sitios de IA cambian su página con frecuencia. Si un sitio cambia el botón de enviar, la
  revisión por clic puede dejar de funcionar. La revisión por Enter y al pegar depende menos de eso.
- No revisa archivos adjuntos ni texto que se arrastra al cuadro.
- No funciona en páginas internas del navegador (`chrome://`) ni en la tienda de extensiones.
