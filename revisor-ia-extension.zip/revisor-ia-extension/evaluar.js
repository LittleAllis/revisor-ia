/*
 * Evaluación automática: node evaluar.js
 * Corre todo el banco, imprime métricas y las compara con la corrida anterior (ultima_evaluacion.json).
 * Si la detección o la precisión bajan, avisa "REGRESIÓN" y termina con código 1 (útil para CI).
 * Use --forzar para guardar el resultado como nueva referencia aunque haya regresión.
 */
const fs = require('fs');
const D = require('./detector.js');
const BANCO = require('./banco_pruebas.js');

const r = D.evaluar(BANCO);
const pct = (x) => (x === null ? 'n/d' : (x * 100).toFixed(1) + '%');
console.log(`Textos: ${r.textos} | VP ${r.vp} · FP ${r.fp} · FN ${r.fn}`);
console.log(`Detección ${pct(r.exhaustividad)} | Precisión ${pct(r.precision)} | Falsos positivos (textos limpios) ${pct(r.tasaFP)} | ${r.tiempoMs.toFixed(3)} ms/texto`);
console.log('\nPor tipo de caso:');
Object.entries(r.porTipo).forEach(([t, k]) => console.log(`  ${t.padEnd(9)} textos ${String(k.textos).padStart(3)}  VP ${k.vp}  FP ${k.fp}  FN ${k.fn}  detección ${pct(k.vp + k.fn ? k.vp / (k.vp + k.fn) : null)}`));
console.log('\nCasos con error:');
r.detalle.filter((d) => d.fp || d.fn).forEach((d) => console.log(`  #${d.id} [${d.tipo}] FP=${d.fp} FN=${d.fn} :: ${d.texto.replace(/\n/g, ' ').slice(0, 70)}`));

const ARCHIVO = __dirname + '/ultima_evaluacion.json';
let regresion = false;
if (fs.existsSync(ARCHIVO)) {
  const prev = JSON.parse(fs.readFileSync(ARCHIVO, 'utf8'));
  if (r.textos === prev.textos) { // solo compara si el banco no cambió de tamaño
    regresion = r.exhaustividad < prev.exhaustividad - 1e-9 || r.precision < prev.precision - 1e-9;
    console.log(`\nComparación con ${prev.fecha}: detección ${pct(prev.exhaustividad)} → ${pct(r.exhaustividad)}, precisión ${pct(prev.precision)} → ${pct(r.precision)}`);
  } else console.log(`\nEl banco cambió (${prev.textos} → ${r.textos} textos): se guarda como nueva referencia.`);
}
if (regresion && !process.argv.includes('--forzar')) { console.log('⚠ REGRESIÓN: el cambio empeoró las métricas. No se guardó la referencia.'); process.exitCode = 1; }
else fs.writeFileSync(ARCHIVO, JSON.stringify({ fecha: new Date().toISOString().slice(0, 10), textos: r.textos, exhaustividad: r.exhaustividad, precision: r.precision }, null, 2));
