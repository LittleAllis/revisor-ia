/*
 * Banco de pruebas: TODOS los datos son ficticios (dominios .test, IP de documentación RFC 5737,
 * números inventados). Formato: [tipo, texto, [[categoría, valor esperado], ...]]
 * tipo: "sensible" (contiene datos), "limpio" (no contiene), "ambiguo" (caso difícil) o "evasion" (intento de saltarse la herramienta).
 * El valor esperado es lo que un revisor humano marcaría como dato sensible.
 */
const BANCO = [
  // ---------------- SENSIBLES (30) ----------------
  ['sensible', 'Resume esta solicitud del cliente Ana, correo ana.ejemplo@empresa.test y celular 300 123 4567', [['CORREO', 'ana.ejemplo@empresa.test'], ['CELULAR', '300 123 4567']]],
  ['sensible', 'Escríbele a juan.perez@correo.test para confirmar la cita del lunes.', [['CORREO', 'juan.perez@correo.test']]],
  ['sensible', 'Reenvía el adjunto a soporte+ventas@mail.empresa.test cuanto antes.', [['CORREO', 'soporte+ventas@mail.empresa.test']]],
  ['sensible', 'Copia a maria.gomez@empresa.test y a pedro_ruiz@empresa.test en la respuesta.', [['CORREO', 'maria.gomez@empresa.test'], ['CORREO', 'pedro_ruiz@empresa.test']]],
  ['sensible', 'El administrador es ADMIN@EMPRESA.TEST, redacta un aviso para él.', [['CORREO', 'ADMIN@EMPRESA.TEST']]],
  ['sensible', 'Llámame al +57 310 555 0199 y te explico el caso.', [['CELULAR', '+57 310 555 0199']]],
  ['sensible', 'Contacto del proveedor: 315-555-0142, pregunta por Luis.', [['CELULAR', '315-555-0142']]],
  ['sensible', 'Mi WhatsApp es 3205550123, ayúdame a redactar el mensaje.', [['CELULAR', '3205550123']]],
  ['sensible', 'Teléfono del titular: 300.123.4567', [['CELULAR', '300.123.4567']]],
  ['sensible', 'Datos de contacto: 573001234567 (horario de oficina).', [['CELULAR', '573001234567']]],
  ['sensible', 'Cédula 1.234.567.890 del titular de la cuenta, verifica si el formato es correcto.', [['DOCUMENTO', '1.234.567.890']]],
  ['sensible', 'El cliente se identifica con CC 1234567890 y vive en Barranquilla.', [['DOCUMENTO', '1234567890']]],
  ['sensible', 'Documento de identidad 80.123.456 presentado en ventanilla.', [['DOCUMENTO', '80.123.456']]],
  ['sensible', 'Identificación: 52345678, redacta la carta de respuesta.', [['DOCUMENTO', '52345678']]],
  ['sensible', 'La empresa proveedora tiene NIT 900.123.456-8 y factura mensual.', [['DOCUMENTO', '900.123.456-8']]],
  ['sensible', 'Registra al aliado con NIT 830012345-9 en el sistema.', [['DOCUMENTO', '830012345-9']]],
  ['sensible', 'El servidor 192.0.2.10 no responde, ayúdame a diagnosticar.', [['IP', '192.0.2.10']]],
  ['sensible', 'Conecta la app a 10.0.0.15 y luego a 172.16.5.4 para la réplica.', [['IP', '10.0.0.15'], ['IP', '172.16.5.4']]],
  ['sensible', 'Bloquea en el firewall la dirección 198.51.100.23 por favor.', [['IP', '198.51.100.23']]],
  ['sensible', 'Revisa esta configuración: api_key=EJEMPLO_NO_REAL', [['CREDENCIAL', 'api_key=EJEMPLO_NO_REAL']]],
  ['sensible', 'Para entrar usa password: Clave123! y cambia el puerto.', [['CREDENCIAL', 'password: Clave123!']]],
  ['sensible', 'Mi contraseña es Verano2025, ¿es segura?', [['CREDENCIAL', 'contraseña es Verano2025']]],
  ['sensible', 'Depura esto: token=abcd1234efgh5678 devuelve 401.', [['CREDENCIAL', 'token=abcd1234efgh5678']]],
  ['sensible', 'Mi llave es sk-EJEMPLO0123456789abcdefghij y no funciona.', [['CREDENCIAL', 'sk-EJEMPLO0123456789abcdefghij']]],
  ['sensible', 'Las credenciales de AWS de prueba: AKIAIOSFODNN7EXAMPLE', [['CREDENCIAL', 'AKIAIOSFODNN7EXAMPLE']]],
  ['sensible', 'Authorization: Bearer abcdefghijklmnopqrstuvwxyz012345 en la cabecera.', [['CREDENCIAL', 'Bearer abcdefghijklmnopqrstuvwxyz012345']]],
  ['sensible', 'Decodifica: eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJlamVtcGxvIn0.firmaEjemplo1234', [['CREDENCIAL', 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJlamVtcGxvIn0.firmaEjemplo1234']]],
  ['sensible', 'Cliente: cédula 1.098.765.432, celular 301 555 0177, correo cliente@empresa.test. Redacta la respuesta.', [['DOCUMENTO', '1.098.765.432'], ['CELULAR', '301 555 0177'], ['CORREO', 'cliente@empresa.test']]],
  ['sensible', 'const db = { host: "192.0.2.55", password: "Ejemplo#2025" }; // ¿hay algún error aquí?', [['IP', '192.0.2.55'], ['CREDENCIAL', 'password: "Ejemplo#2025"']]],
  ['sensible', 'Escribe un recordatorio para 3001112233 y 3109998877 con copia a gerencia@empresa.test', [['CELULAR', '3001112233'], ['CELULAR', '3109998877'], ['CORREO', 'gerencia@empresa.test']]],

  // ---------------- LIMPIOS (14) ----------------
  ['limpio', 'Resume este artículo sobre ciberseguridad en cinco puntos.', []],
  ['limpio', 'Explícame qué es una inyección SQL y cómo prevenirla.', []],
  ['limpio', 'Redacta un correo de agradecimiento para un cliente satisfecho.', []],
  ['limpio', 'El proyecto tiene 3 fases y 5 entregables en total.', []],
  ['limpio', 'La reunión es el 12 de marzo a las 3:30 pm en la sala principal.', []],
  ['limpio', 'Traduce al inglés: buenos días equipo, empezamos la jornada.', []],
  ['limpio', 'Escribe una función en Python que sume los elementos de dos listas.', []],
  ['limpio', 'El presupuesto es de $ 1.500.000 para el trimestre.', []],
  ['limpio', 'Pagamos 2.500.000 pesos por el servicio de mantenimiento.', []],
  ['limpio', 'Actualizamos a la versión 2.3.4.5 del software la semana pasada.', []],
  ['limpio', 'Mi código postal es 080001, ¿cómo lo escribo en un formulario?', []],
  ['limpio', 'El pedido número 458712 llegó tarde, redacta una queja formal.', []],
  ['limpio', 'La clave del éxito en un proyecto es la constancia y la planeación.', []],
  ['limpio', 'Dame ideas para una campaña en redes sociales sobre seguridad digital.', []],

  // ---------------- AMBIGUOS / DIFÍCILES (11) ----------------
  ['ambiguo', 'Datos del cliente: Ana Torres, 1098765432, Barranquilla.', [['DOCUMENTO', '1098765432']]],
  ['ambiguo', 'Su correo es ana [arroba] empresa.test, por si lo necesitas.', [['CORREO', 'ana [arroba] empresa.test']]],
  ['ambiguo', 'Cel: 300 123 45 67, atiende por las tardes.', [['CELULAR', '300 123 45 67']]],
  ['ambiguo', 'El token de acceso: 4f8a9c21b7d3 vence mañana.', [['CREDENCIAL', '4f8a9c21b7d3']]],
  ['ambiguo', 'Mi cédula es 3012345678, verifica el formato.', [['DOCUMENTO', '3012345678']]],
  ['ambiguo', 'Prueba con la IP 999.1.1.1 que es inválida.', []],
  ['ambiguo', 'Mi teléfono fijo es 605 123 4567, ¿cómo lo escribo con indicativo?', []],
  ['ambiguo', 'La contraseña debe tener mínimo 8 caracteres y un símbolo.', []],
  ['ambiguo', 'Total a pagar: 12.500.000 incluyendo impuestos.', []],
  ['ambiguo', 'El radicado 20240001234 corresponde al juzgado civil.', []],
  ['ambiguo', 'El equipo quedó con el build 10.2.3.4 estable.', []],
  // ---------------- AMPLIACIÓN v2 ----------------
  // Categorías nuevas (sensibles)
  ['sensible', 'Mi tarjeta Visa es 4111 1111 1111 1111, vence el 12/29, ¿es seguro guardarla así?', [['TARJETA', '4111 1111 1111 1111'], ['TARJETA', 'vence el 12/29']]],
  ['sensible', 'Pago con 5500-0000-0000-0004 rechazado, revisa el error.', [['TARJETA', '5500-0000-0000-0004']]],
  ['sensible', 'Cobro a la tarjeta 378282246310005 de la cliente.', [['TARJETA', '378282246310005']]],
  ['sensible', 'Consigna a la cuenta de ahorros 4567890123 de la proveedora.', [['CUENTA', '4567890123']]],
  ['sensible', 'La cuenta bancaria número 123-456789-01 es la de nómina.', [['CUENTA', '123-456789-01']]],
  ['sensible', 'Configura el servidor con esto:\n-----BEGIN PRIVATE KEY-----\nMIIEEJEMPLOEJEMPLOEJEMPLO0123456789\nabcdefEJEMPLOabcdef\n-----END PRIVATE KEY-----\ny reinícialo.', [['LLAVE_PRIVADA', '-----BEGIN PRIVATE KEY-----\nMIIEEJEMPLOEJEMPLOEJEMPLO0123456789\nabcdefEJEMPLOabcdef\n-----END PRIVATE KEY-----']]],
  ['sensible', 'Escríbeme a ana.torres(at)empresa.test cuando tengas el informe.', [['CORREO', 'ana.torres(at)empresa.test']]],
  // Limpios nuevos
  ['limpio', 'El número de serie 4111-1111-1111-1112 corresponde al equipo del laboratorio.', []],
  ['limpio', 'Mi tarjeta termina en 1111, ¿cómo la reporto como perdida?', []],
  ['limpio', 'Ten en cuenta 20240001 como referencia del contrato, sin más trámites.', []],
  // Ambiguo nuevo
  ['ambiguo', 'La dirección IPv6 2001:db8::8a2e:370:7334 responde al ping.', [['IP', '2001:db8::8a2e:370:7334']]],

  // Caso real reportado por el equipo al probar la herramienta (número de tarjeta inventado que falla Luhn)
  ['ambiguo', 'el estudiante luis aguilar quiere realizar un pago mediante su tarjeta que es 1234432156788765, su expiracion es 05/31, y su cvv es 123, la compañia encargada de realizar el pago es VISA, y mediate esta nosotros Allied, vamos a encargarnos de añadir los servicios al numero 1231234323, cuyo dueño de esta linea es maicol villalobos', [['TARJETA', '1234432156788765'], ['TARJETA', 'expiracion es 05/31'], ['TARJETA', 'cvv es 123'], ['CELULAR', '1231234323']]],

  // ---------------- PRUEBAS DE EVASIÓN ("agente atacante") ----------------
  // Escritas a propósito para intentar saltarse la herramienta, sin consultar las reglas.
  ['evasion', 'Mi correo: ana.torres @ empresa.test, escríbeme.', [['CORREO', 'ana.torres @ empresa.test']]],
  ['evasion', 'Contáctame en ANA PUNTO TORRES ARROBA EMPRESA PUNTO TEST', [['CORREO', 'ANA PUNTO TORRES ARROBA EMPRESA PUNTO TEST']]],
  ['evasion', 'Escríbeme a ana.torres＠empresa.test (con arroba de ancho completo).', [['CORREO', 'ana.torres＠empresa.test']]],
  ['evasion', 'Mándalo a ana.torres[at]empresa[dot]test por favor.', [['CORREO', 'ana.torres[at]empresa[dot]test']]],
  ['evasion', 'Datos en base64: YW5hLnRvcnJlc0BlbXByZXNhLnRlc3Q=', [['CORREO', 'YW5hLnRvcnJlc0BlbXByZXNhLnRlc3Q=']]],
  ['evasion', 'Cel +57 (300) 123-4567 para urgencias.', [['CELULAR', '+57 (300) 123-4567']]],
  ['evasion', 'WhatsApp 3 0 0 1 2 3 4 5 6 7 solo mensajes.', [['CELULAR', '3 0 0 1 2 3 4 5 6 7']]],
  ['evasion', 'Mi CC es 1234 567 890, anótala en el formulario.', [['DOCUMENTO', '1234 567 890']]],
  ['evasion', 'Cédula de ciudadanía número 1098765432 del solicitante.', [['DOCUMENTO', '1098765432']]],
  ['evasion', 'La IP es 192 . 0 . 2 . 10, no responde.', [['IP', '192 . 0 . 2 . 10']]],
  ['evasion', 'Servidor interno: [192.0.2.10] caído desde ayer.', [['IP', '192.0.2.10']]],
  ['evasion', 'La clave de acceso al servidor es: Tr0ub4dor&3 (no la compartas).', [['CREDENCIAL', 'Tr0ub4dor&3']]],
  ['evasion', 'usuario: admin / contraseña: Ejemplo2025 para el panel.', [['CREDENCIAL', 'contraseña: Ejemplo2025']]],
  ['evasion', 'Authorization: Basic YWRtaW46RWplbXBsbzIwMjU= en la petición.', [['CREDENCIAL', 'Basic YWRtaW46RWplbXBsbzIwMjU=']]],
  ['evasion', 'En consola corrí: export DB_PASS=Ejemplo#2025 y falló.', [['CREDENCIAL', 'DB_PASS=Ejemplo#2025']]],
  ['evasion', 'postgres://admin:Ejemplo2025@192.0.2.20:5432/nomina da timeout.', [['IP', '192.0.2.20'], ['CREDENCIAL', 'admin:Ejemplo2025']]],
  ['evasion', 'Tarjeta 4111.1111.1111.1111 de la clienta.', [['TARJETA', '4111.1111.1111.1111']]],
  ['evasion', 'CORREO:ANA@EMPRESA.TEST;PEDRO@EMPRESA.TEST;', [['CORREO', 'ANA@EMPRESA.TEST'], ['CORREO', 'PEDRO@EMPRESA.TEST']]],
];

if (typeof module !== 'undefined' && module.exports) module.exports = BANCO;
